create database biblioteca;
use biblioteca;
create table usuario (
nome varchar(255),
email varchar(255) primary key,
senha varchar(255));
select * from usuario;

create table livros( id int, nome varchar(200), autor varchar(200), preco decimal(5,2),descricao varchar(255), imagem varchar(255));
insert into livros (id, nome, autor,preco, descricao, imagem) values (1, 'Os dois morrem no final', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (2, 'Em algum lugar nas estrelas	', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (3, 'Edgar Allan Poe', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (4, 'Harry Potter e a pedra filosofal	', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (5, 'A biblioteca da meia noite', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (6, '1984', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (7, ' Box de jogos vorazes	', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (8, 'Em fim Capivaras', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (9, 'Dom Casmurro', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (10, 'Be Real', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (11, 'Lady Killers', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (12, 'Alice no pais das maravilhas', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (13, 'As cronicas das sombras', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (14, 'O morro dos ventos uivantes', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (15, 'O Deus que destroi sonhos', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');
insert into livros (id, nome, autor,preco, descricao, imagem) values (16, 'Box de amor e livros	', 'sabrina', 60.99, 'é um livro de ficção onde se passa em panem uma ciades dividida em distritos', 'assets\img\gallery\1.png');

